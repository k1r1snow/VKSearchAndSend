import vk_api
from vk_api.utils import get_random_id
from urllib.parse import urlparse


# Функция для извлечения ID группы из ссылки
def extract_group_id(group_link):
    parsed_url = urlparse(group_link)
    if parsed_url.netloc == 'vk.com':
        path = parsed_url.path.strip('/')
        if path.startswith('public'):
            return '-' + path[6:]
        elif path.startswith('id'):
            return None  # Не обрабатываем ссылки на страницы пользователей
        else:
            return '-' + path
    else:
        return None  # Не обрабатываем неверные ссылки


# Функция для получения последнего поста из группы
def get_last_post(group_id, api_token):
    try:
        # Авторизация в ВКонтакте
        vk_session = vk_api.VkApi(token=api_token)
        vk = vk_session.get_api()

        # Получаем информацию о последнем посте в группе
        response = vk.wall.get(owner_id=group_id, count=1)
        if response['items']:
            last_post = response['items'][0]
            return last_post
        else:
            print(f"В группе {group_id} нет постов.")
            return None
    except vk_api.exceptions.ApiError as e:
        print(f"Ошибка при получении постов из группы {group_id}: {e}")
        return None


# Функция для отправки комментария к посту
def send_comment(api_token, owner_id, post_id, comment_text):
    try:
        # Авторизация в ВКонтакте
        vk_session = vk_api.VkApi(token=api_token)

        # Отправляем комментарий
        response = vk_session.method('wall.createComment', {
            'owner_id': owner_id,
            'post_id': post_id,
            'message': comment_text,
            'guid': get_random_id(),  # Генерация уникального ключа
        })

        print("Результат отправки комментария:", response)
        return f"https://vk.com/wall{owner_id}_{post_id}"  # Возвращаем ссылку на пост
    except vk_api.exceptions.ApiError as e:
        print(f"Ошибка при отправке комментария: {e}")
        return None


if __name__ == "__main__":
    # Введите ваш API ключ от ВКонтакте
    api_token = input("Введите ваш API ключ от ВКонтакте: ")

    # Ввод ссылок на группы ВКонтакте
    group_links = []
    print("Введите ссылки на группы ВКонтакте (по одной ссылке в каждой строке, пустая строка для завершения):")
    while True:
        link = input()
        if not link:
            break
        group_links.append(link)

    # Список для хранения ссылок на посты, к которым отправлены комментарии
    commented_posts = []

    # Обработка каждой группы
    for group_link in group_links:
        group_id = extract_group_id(group_link)
        if group_id:
            last_post = get_last_post(group_id, api_token)
            if last_post:
                # Формируем ссылку на последний пост
                last_post_link = f"https://vk.com/wall{group_id}_{last_post['id']}"

                # Запрос комментария у пользователя (многострочный ввод)
                print(
                    f"Введите комментарий к последнему посту в группе {group_id}: (для завершения введите пустую строку)")
                lines = []
                while True:
                    line = input()
                    if not line:
                        break
                    lines.append(line)
                comment_text = '\n'.join(lines)

                # Отправляем комментарий к последнему посту
                post_comment_link = send_comment(api_token, group_id, last_post['id'], comment_text)
                if post_comment_link:
                    commented_posts.append(post_comment_link)
        else:
            print(f"Неверная ссылка на группу: {group_link}")

    # Вывод списка ссылок на посты, к которым отправлены комментарии
    print("\nСсылки на посты, к которым отправлены комментарии:")
    for post_link in commented_posts:
        print(post_link)
